"""Current Google Gen AI SDK adapter with bounded calls and safe errors."""

import json

import httpx
from google import genai
from google.genai import errors, types

from ai_core.demo_generator import analyze_demo, generate_demo
from ai_core.prompts import ANALYSIS_SYSTEM, GENERATION_SYSTEM
from config import Settings
from models import Analysis, AnalysisRequest, DocumentRequest


class GenerationError(Exception):
    def __init__(self, message: str, status_code: int = 502):
        super().__init__(message)
        self.status_code = status_code


class GeminiDocumentGenerator:
    def __init__(self, settings: Settings):
        self.settings = settings

    def _call(self, payload: dict, instruction: str, structured: bool = False):
        key = self.settings.gemini_api_key.get_secret_value()
        if not key:
            raise GenerationError(
                "Gemini mode requires GEMINI_API_KEY in the backend .env file. Restart after setting it.", 503
            )
        config = types.GenerateContentConfig(
            system_instruction=instruction,
            max_output_tokens=12000,
            automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True),
            **({"response_mime_type": "application/json", "response_schema": Analysis} if structured else {}),
        )
        # One retry for transient server failures. Share the configured wait budget
        # between attempts, leaving two seconds for the retry delay and overhead.
        attempt_timeout_ms = max(1000, (self.settings.request_timeout_seconds * 1000 - 2000) // 2)
        try:
            with genai.Client(
                api_key=key,
                http_options=types.HttpOptions(
                    timeout=attempt_timeout_ms,
                    retry_options=types.HttpRetryOptions(
                        attempts=2,
                        initial_delay=1,
                        max_delay=1,
                        jitter=0,
                        http_status_codes=[500, 502, 503, 504],
                    ),
                ),
            ) as client:
                response = client.models.generate_content(
                    model=self.settings.gemini_model, contents=json.dumps(payload, ensure_ascii=False), config=config
                )
            candidates = response.candidates or []
            reason = str(candidates[0].finish_reason) if candidates else ""
            if reason and not reason.endswith("STOP"):
                raise GenerationError(
                    "Gemini could not return a complete draft. Shorten the request or revise its content."
                )
            text = (response.text or "").strip()
            if not text or len(text) > 60000:
                raise GenerationError("Gemini returned an empty or oversized response. Try a shorter request.")
            return text
        except errors.APIError as exc:
            code = getattr(exc, "code", None)
            if code == 503:
                raise GenerationError(
                    "Google Gemini is overloaded (HTTP 503), and the automatic retry also failed. "
                    "Wait briefly and generate again, or choose another GEMINI_MODEL in .env and restart the app.",
                    503,
                ) from None
            if code == 504:
                raise GenerationError(
                    "Google Gemini exceeded its response deadline (HTTP 504). Try a shorter request.", 504
                ) from None
            if code == 429:
                raise GenerationError(
                    "Gemini quota or rate limit reached. Check your Google AI Studio quota and retry later.", 429
                ) from None
            if code == 402:
                raise GenerationError(
                    "Google rejected generation because billing or prepaid credits require attention (HTTP 402). "
                    "Check your project in Google AI Studio; retrying will not resolve this.",
                    502,
                ) from None
            if code == 404:
                raise GenerationError(
                    "The configured Gemini model was not found or is unavailable to this project (HTTP 404). "
                    "Update GEMINI_MODEL in .env to a model available in Google AI Studio, then restart.",
                    502,
                ) from None
            if code in (400, 401, 403):
                raise GenerationError(
                    f"Google rejected the Gemini request (HTTP {code}). "
                    "Check the API key, project permissions and billing in Google AI Studio.",
                    502,
                ) from None
            if code in (500, 502):
                raise GenerationError(
                    f"Google Gemini returned a server error (HTTP {code}) after retrying. Try again shortly.", 502
                ) from None
            raise GenerationError(
                "Google Gemini could not complete the request. Please try again later.", 502
            ) from None
        except httpx.TimeoutException:
            raise GenerationError("Gemini timed out. Try again with a shorter request.", 504) from None
        except httpx.HTTPError:
            raise GenerationError("Unable to reach Gemini. Check the backend network connection.", 502) from None

    def generate_document(self, request: DocumentRequest) -> str:
        if self.settings.ai_provider == "demo":
            if request.language != "English":
                raise GenerationError("Offline demo supports English only. Enable Gemini for other languages.", 422)
            return generate_demo(request)
        return self._call(request.model_dump(), GENERATION_SYSTEM)

    def analyze(self, request: AnalysisRequest) -> Analysis:
        if self.settings.ai_provider == "demo":
            if request.language != "English":
                raise GenerationError("Offline demo supports English only. Enable Gemini for other languages.", 422)
            return analyze_demo(request.document)
        result = self._call(request.model_dump(), ANALYSIS_SYSTEM, structured=True)
        try:
            return Analysis.model_validate_json(result)
        except ValueError:
            raise GenerationError("Gemini returned an invalid review. Please retry.") from None
