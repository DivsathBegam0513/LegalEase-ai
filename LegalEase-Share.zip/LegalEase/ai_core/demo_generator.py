"""Deterministic English-only examples. These are explicitly NOT AI output."""

import re

from models import Analysis, DocumentRequest

TYPE_SECTIONS = {
    "employment": (
        "Role and compensation",
        "Job title, duties, work location, hours, compensation, benefits and leave: [TO BE COMPLETED].",
    ),
    "lease": (
        "Premises and occupancy",
        "Property address, permitted use, rent, deposit, maintenance duties and lease end date: [TO BE COMPLETED].",
    ),
    "non-disclosure": (
        "Confidential information",
        "Define the information covered, the permitted purpose, exclusions, recipients and confidentiality period: [TO BE COMPLETED].",
    ),
    "nda": (
        "Confidential information",
        "Define the information covered, the permitted purpose, exclusions, recipients and confidentiality period: [TO BE COMPLETED].",
    ),
    "freelance": (
        "Services and deliverables",
        "Scope, milestones, acceptance criteria, fees, invoicing and ownership of work: [TO BE COMPLETED].",
    ),
}


def generate_demo(request: DocumentRequest) -> str:
    terms = [p.strip() for p in re.split(r"[;\n]+", request.terms) if p.strip()]
    heading, details = next(
        (v for k, v in TYPE_SECTIONS.items() if k in request.document_type.lower()),
        (
            "Purpose and scope",
            "Describe the agreed purpose, deliverables and each party's responsibilities: [TO BE COMPLETED].",
        ),
    )
    clauses = "\n".join("- " + term for term in terms)
    return f"""# {request.document_type}

OFFLINE DEMO TEMPLATE - NOT AI-GENERATED. Draft for professional review only.

## Parties and effective date
Parties: {request.parties}
Effective date: {request.dates}
Jurisdiction for review: {request.jurisdiction}

## {heading}
{details}
Complete the missing details consistently with the supplied Key Terms below.

## Key Terms
{clauses}

## Duration and termination
Duration, notice requirements, grounds for termination and obligations surviving termination: [TO BE COMPLETED].

## Disputes and applicable law
The parties must confirm the applicable jurisdiction, dispute process and any mandatory requirements with a qualified legal professional. No legal compliance assessment has been performed.

## Review and signatures
Resolve all placeholders and inconsistencies before signing. This offline template is a software demonstration and does not determine legal rights or obligations.

Party 1 name: ____________________
Signature: ____________________    Date: ____________________

Party 2 name: ____________________
Signature: ____________________    Date: ____________________"""


def analyze_demo(document: str) -> Analysis:
    headings = [s.lstrip("# ").strip() for s in document.splitlines() if s.startswith("## ")]
    excerpt = " ".join(document.split())[:400]
    points = ["Offline mode extracts text and headings only; it cannot assess legal meaning or completeness."]
    if "[TO BE COMPLETED" in document or "____" in document:
        points.append("Unfilled placeholders or signature lines were found; review them before using the draft.")
    return Analysis(
        summary=f"Offline text extract ({len(document.split())} words): {excerpt}",
        key_clauses=headings[:20] or ["No section headings were identified."],
        review_points=points,
    )
