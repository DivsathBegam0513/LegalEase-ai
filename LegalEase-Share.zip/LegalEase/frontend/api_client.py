"""Server-side API calls; secrets never travel to browser-side JavaScript."""

import httpx

from config import get_settings


class APIError(Exception):
    pass


def request_api(path: str, payload: dict | None = None, *, binary: bool = False):
    settings = get_settings()
    headers = {}
    if settings.backend_api_key.get_secret_value():
        headers["X-API-Key"] = settings.backend_api_key.get_secret_value()
    try:
        with httpx.Client(timeout=3 if payload is None else settings.request_timeout_seconds + 15) as client:
            url = settings.backend_url.rstrip("/") + path
            response = (
                client.get(url, headers=headers) if payload is None else client.post(url, headers=headers, json=payload)
            )
        if response.is_error:
            try:
                detail = response.json().get("detail", "The request failed.")
            except ValueError:
                detail = "The server returned an unexpected error."
            if isinstance(detail, list):
                detail = "\n".join(
                    f"{' / '.join(str(v) for v in e.get('loc', [])[1:])}: {e.get('msg', 'Invalid value')}"
                    for e in detail
                )
            raise APIError(str(detail))
        return response.content if binary else response.json()
    except httpx.TimeoutException:
        raise APIError("The request timed out. Check the backend terminal and try a shorter request.") from None
    except httpx.HTTPError:
        raise APIError("Cannot reach the backend. Start it on port 8000 or check BACKEND_URL in .env.") from None
    except ValueError:
        raise APIError(
            "The backend returned an invalid response. Check BACKEND_URL and the backend terminal."
        ) from None
