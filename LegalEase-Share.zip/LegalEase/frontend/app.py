"""LegalEase drafting workspace. State belongs only to the current session."""

import base64
from datetime import date
from html import escape

import streamlit as st

from config import ROOT
from frontend.api_client import APIError, request_api
from models import NOTICE
from services.exporter import MIME, safe_filename
from services.text import format_html_preview

TYPES = [
    "Non-Disclosure Agreement",
    "Employment Contract",
    "Residential Lease Agreement",
    "Freelance Work Contract",
    "Service Agreement",
    "Custom document",
]
EXAMPLES = {
    "Non-Disclosure Agreement": (
        "Northstar Studio (Disclosing Party); Riverbend Labs (Receiving Party)",
        "Purpose: evaluating a design partnership; Use information only for the stated purpose; Return confidential materials on request; Confidentiality period: two years",
    ),
    "Employment Contract": (
        "Northstar Studio (Employer); Alex Morgan (Employee)",
        "Role: Product Designer; Salary: USD 65,000 per year; Work schedule: 40 hours per week; Start date to be confirmed; Confidentiality obligations apply",
    ),
    "Residential Lease Agreement": (
        "Alex Morgan (Landlord); Sam Taylor (Tenant)",
        "Property: 12 Example Street, Unit 3; Rent: USD 1,200 per month; Term: 12 months; Deposit: USD 1,200; Permitted use: residential",
    ),
    "Freelance Work Contract": (
        "Alex Morgan (Freelancer); Northstar Studio (Client)",
        "Deliver three website concepts; Fee: USD 2,500; Two revision rounds included; Payment within 30 days of invoice; Ownership transfers after full payment",
    ),
    "Service Agreement": (
        "Northstar Studio (Provider); Riverbend Labs (Client)",
        "Provide monthly design support; Fee: USD 1,000 per month; Scope changes require written agreement; Either party may end with 30 days notice",
    ),
}


def clear_workspace():
    for key in list(st.session_state):
        del st.session_state[key]


def accept_draft(text: str, title: str, source: str):
    st.session_state.update(document=text, editor=text, draft_title=title, source=source)
    for key in ["downloads", "analysis"]:
        st.session_state.pop(key, None)


def main():
    st.set_page_config(
        page_title="LegalEase | Drafting workspace", page_icon="⚖", layout="wide", initial_sidebar_state="collapsed"
    )
    st.markdown(
        "<style>" + (ROOT / "frontend/styles.css").read_text(encoding="utf-8") + "</style>", unsafe_allow_html=True
    )
    try:
        health = request_api("/health")
    except APIError:
        health = {"provider": "unknown", "configured": False}
    provider = health["provider"]

    with st.sidebar:
        st.markdown(
            '<div class="brand">Legal<span>Ease</span></div><div class="eyebrow">The drafting workspace</div>',
            unsafe_allow_html=True,
        )
        st.divider()
        if provider == "demo":
            st.info("Offline demo\n\nTemplates only. No data is sent to an AI provider.")
        elif provider == "gemini":
            st.success("Gemini key configured" if health["configured"] else "Gemini mode selected")
            st.caption("Model: " + health.get("model", "configured model"))
            if not health["configured"]:
                st.warning("Add GEMINI_API_KEY to .env and restart the backend.")
        else:
            st.warning("Backend offline. Run python run.py from the project folder.")
        st.markdown("**Your workspace**")
        st.caption("1. Add parties and terms\n\n2. Generate and refine\n\n3. Review and download")
        st.divider()
        st.caption(
            "Drafts stay in this browser session. Downloads are saved by your browser. Gemini mode sends submitted text to Google when you generate or review."
        )
        st.button("Clear workspace", on_click=clear_workspace, width="stretch")
        st.caption(NOTICE)

    st.markdown(
        '<div class="hero"><div class="eyebrow">Clear terms. A better starting point.</div>'
        "<h1>From your terms to a thoughtful draft.</h1>"
        "<p>Create an agreement, shape the wording, and take a clean document into your next conversation.</p></div>",
        unsafe_allow_html=True,
    )
    left, right = st.columns([0.95, 1.4], gap="large")
    consent = False
    with left:
        st.markdown('<div class="step">01 / DOCUMENT DETAILS</div>', unsafe_allow_html=True)
        create_tab, import_tab = st.tabs(["Create a draft", "Import a document"])
        with create_tab:
            document_type = st.selectbox("Document type", TYPES, key="type")
            example = EXAMPLES.get(
                document_type,
                (
                    "First party (role); Second party (role)",
                    "Describe the purpose; Set obligations; Include amounts, dates and notice periods",
                ),
            )
            with st.expander("See an example"):
                st.write("**Parties:** " + example[0])
                st.write("**Terms:** " + example[1])
            with st.form("generate_form"):
                title = (
                    st.text_input("Custom document title", max_chars=80)
                    if document_type == "Custom document"
                    else document_type
                )
                parties = st.text_area(
                    "Parties involved", placeholder=example[0], height=110, max_chars=4000, key="parties"
                )
                terms = st.text_area(
                    "Terms and conditions",
                    placeholder=example[1],
                    height=180,
                    max_chars=12000,
                    key="terms",
                    help="Separate terms with semicolons or new lines. Include the facts you want in the agreement.",
                )
                effective = st.date_input(
                    "Effective date", value=date.today(), min_value=date(1900, 1, 1), max_value=date(2100, 12, 31)
                )
                jurisdiction = st.text_input(
                    "Jurisdiction", placeholder="Country and state / province", max_chars=200, key="jurisdiction"
                )
                language = st.selectbox(
                    "Draft language",
                    ["English"] if provider != "gemini" else ["English", "French", "Spanish", "German"],
                )
                if provider == "gemini":
                    consent = st.checkbox("Send these details to Google Gemini to generate my draft.")
                submitted = st.form_submit_button(
                    "Generate draft", type="primary", width="stretch", disabled=not health["configured"]
                )
            if submitted:
                if not title.strip() or len(parties.strip()) < 5 or len(terms.strip()) < 10:
                    st.error("Enter a document title, the parties, and at least one detailed term.")
                elif provider == "gemini" and not consent:
                    st.error("Confirm that you want to send the details to Gemini.")
                else:
                    try:
                        with st.spinner("Preparing your draft…"):
                            result = request_api(
                                "/generate",
                                {
                                    "document_type": title,
                                    "parties": parties,
                                    "terms": terms,
                                    "dates": effective.isoformat(),
                                    "jurisdiction": jurisdiction.strip() or "Not specified",
                                    "language": language,
                                },
                            )
                        accept_draft(result["document"], title, result["provider"])
                        st.success("Draft ready. Review the details and fill any placeholders.")
                    except APIError as exc:
                        st.error(str(exc))
        with import_tab:
            st.caption(
                "Extract text from TXT, DOCX or a text-based PDF. Original layout is not retained. Maximum 5 MB; PDFs up to 50 pages."
            )
            upload = st.file_uploader("Choose a document", type=["txt", "docx", "pdf"], key="document_upload")
            if st.button("Open for review", disabled=upload is None or provider == "unknown", width="stretch"):
                if upload.size > 5_000_000:
                    st.error("The document must be smaller than 5 MB.")
                else:
                    try:
                        result = request_api(
                            "/extract",
                            {
                                "filename": upload.name,
                                "content_base64": base64.b64encode(upload.getvalue()).decode("ascii"),
                            },
                        )
                        accept_draft(result["document"], "Imported document", "imported")
                        st.success(result["notice"])
                    except APIError as exc:
                        st.error(str(exc))

    with right:
        st.markdown('<div class="step">02 / YOUR DRAFT</div>', unsafe_allow_html=True)
        if "document" not in st.session_state:
            st.markdown(
                '<div class="empty-workspace"><div class="mark">§</div><h3>A clear place to begin.</h3>'
                "<p>Add your parties, dates and key terms. Your editable draft will appear here.</p>"
                '<div class="eyebrow">Preview · Refine · Export</div></div>',
                unsafe_allow_html=True,
            )
        else:
            document = st.session_state["document"]
            st.caption(f"{len(document.split()):,} words · Source: {st.session_state['source']} · Draft for review")
            preview, editor, review = st.tabs(["Document preview", "Edit wording", "Review notes"])
            with editor:
                with st.form("edit_form"):
                    edited = st.text_area(
                        "Document text",
                        key="editor",
                        height=520,
                        max_chars=60000,
                        help="Use # for the title and ## for sections. Lines under ## Key Terms become table rows.",
                    )
                    apply_edits = st.form_submit_button("Apply edits", type="primary")
                if apply_edits:
                    if len(edited.strip()) < 20:
                        st.error("Keep at least 20 characters in the document.")
                    else:
                        st.session_state["document"] = edited
                        st.session_state.pop("downloads", None)
                        st.session_state.pop("analysis", None)
                        st.rerun()
                st.caption("Apply edits before reviewing or preparing downloads. Unsaved typing is not exported.")
            with preview:
                st.markdown(format_html_preview(document), unsafe_allow_html=True)
            with review:
                st.caption(
                    "Review the current saved draft. These notes are separate from the document and are not exported."
                )
                review_language = st.selectbox(
                    "Review language",
                    ["English"] if provider != "gemini" else ["English", "French", "Spanish", "German"],
                )
                review_consent = (
                    st.checkbox("Send this draft to Google Gemini for review.") if provider == "gemini" else True
                )
                if st.button("Review saved draft", disabled=not health["configured"]):
                    if not review_consent:
                        st.error("Confirm that you want to send this draft to Gemini.")
                    else:
                        try:
                            with st.spinner("Reading the saved draft…"):
                                st.session_state["analysis"] = request_api(
                                    "/analyze", {"document": document, "language": review_language}
                                )
                        except APIError as exc:
                            st.error(str(exc))
                if "analysis" in st.session_state:
                    notes = st.session_state["analysis"]
                    st.write("**Summary**")
                    st.text(notes["summary"])
                    for heading, field in [("Key clauses", "key_clauses"), ("Points to review", "review_points")]:
                        st.write("**" + heading + "**")
                        for point in notes[field]:
                            st.text("• " + point)
                    st.caption("Source: " + notes["provider"] + ". " + NOTICE)

            st.markdown(
                '<div class="step" style="margin-top:26px">03 / FINISH & DOWNLOAD</div>', unsafe_allow_html=True
            )
            with st.form("export_form"):
                brand, font_col = st.columns([1.3, 1])
                company = brand.text_input("Brand / company name", value="LegalEase", max_chars=80)
                font = font_col.selectbox("Document font", ["Classic serif", "Clean sans serif"])
                logo = st.file_uploader(
                    "Company logo (optional)",
                    type=["png", "jpg", "jpeg"],
                    help="PNG or JPEG, up to 2 MB and 4 million pixels. Used only in Word and PDF exports.",
                )
                prepare = st.form_submit_button("Prepare downloads", type="primary", width="stretch")
            if prepare:
                st.session_state.pop("downloads", None)
                if logo is not None and logo.size > 2_000_000:
                    st.error("Logo must be smaller than 2 MB.")
                else:
                    branding = {
                        "company_name": company,
                        "font": "serif" if font == "Classic serif" else "sans",
                        "logo_base64": base64.b64encode(logo.getvalue()).decode("ascii") if logo else None,
                    }
                    files = {}
                    with st.spinner("Formatting your documents…"):
                        for extension in ["txt", "docx", "pdf"]:
                            try:
                                files[extension] = request_api(
                                    "/export",
                                    {
                                        "document": document,
                                        "document_type": st.session_state["draft_title"],
                                        "format": extension,
                                        "branding": branding,
                                    },
                                    binary=True,
                                )
                            except APIError as exc:
                                st.error(extension.upper() + ": " + str(exc))
                    st.session_state["downloads"] = files
            if st.session_state.get("downloads"):
                for column, (extension, data) in zip(st.columns(3), st.session_state["downloads"].items()):
                    column.download_button(
                        "Download " + extension.upper(),
                        data,
                        file_name=safe_filename(st.session_state["draft_title"]) + "." + extension,
                        mime=MIME[extension],
                        on_click="ignore",
                        width="stretch",
                    )
                st.caption(
                    "Files reflect the last prepared version and branding. Apply wording edits, then prepare again after any changes."
                )
    st.markdown('<div class="app-footnote">LegalEase · ' + escape(NOTICE) + "</div>", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
