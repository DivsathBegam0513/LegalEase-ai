"""Verify a running API using fictional data. Defaults to the configured backend."""

import argparse
import base64
from io import BytesIO
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import httpx
from docx import Document
from pypdf import PdfReader

from config import ROOT, get_settings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", help="Override BACKEND_URL, e.g. http://127.0.0.1:8001")
    parser.add_argument(
        "--allow-gemini",
        action="store_true",
        help="Explicitly allow fictional example data to be sent to Gemini; quota may be consumed.",
    )
    args = parser.parse_args()
    settings = get_settings()
    headers = {"X-API-Key": settings.backend_api_key.get_secret_value()}
    with httpx.Client(
        base_url=(args.url or settings.backend_url).rstrip("/"),
        headers=headers,
        timeout=settings.request_timeout_seconds + 15,
    ) as client:
        health = client.get("/health")
        health.raise_for_status()
        provider = health.json()["provider"]
        if provider == "gemini" and not args.allow_gemini:
            parser.error(
                "Backend uses Gemini. Add --allow-gemini to send fictional test data, or switch AI_PROVIDER=demo and restart."
            )
        response = client.post(
            "/generate", json=json.loads((ROOT / "examples/nda-request.json").read_text(encoding="utf-8"))
        )
        response.raise_for_status()
        draft = response.json()["document"] + "\n\nSMOKE TEST EDIT: reviewed example."
        assert len(draft) > 100
        for extension in ["txt", "docx", "pdf"]:
            response = client.post(
                "/export", json={"document": draft, "document_type": "Test NDA", "format": extension}
            )
            response.raise_for_status()
            data = response.content
            if extension == "txt":
                extracted = data.decode("utf-8")
            elif extension == "docx":
                extracted = "\n".join(p.text for p in Document(BytesIO(data)).paragraphs)
            else:
                extracted = "\n".join(p.extract_text() for p in PdfReader(BytesIO(data)).pages)
            assert "SMOKE TEST EDIT" in extracted, extension + " omitted the edited text"
            print(extension.upper() + " export: passed")
        response = client.post("/analyze", json={"document": draft})
        response.raise_for_status()
        assert response.json()["summary"]
        response = client.post(
            "/extract", json={"filename": "example.txt", "content_base64": base64.b64encode(draft.encode()).decode()}
        )
        response.raise_for_status()
        assert response.json()["document"] == draft
    print(f"Generation, editing, exports, review and import passed. Provider: {provider}.")


if __name__ == "__main__":
    main()
