"""TXT, DOCX and Unicode PDF export from the same current edited document."""

import base64
import binascii
from io import BytesIO
import re
import textwrap
import warnings

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from fpdf import FPDF
from fpdf.fonts import FontFace
from PIL import Image, UnidentifiedImageError

from config import ROOT
from models import Branding, ExportRequest, NOTICE
from services.text import parse_document, sanitize_text

MIME = {
    "txt": "text/plain; charset=utf-8",
    "pdf": "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}


def safe_filename(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", name).strip("-")[:70] or "legal-document"


def logo_bytes(branding: Branding) -> bytes | None:
    if not branding.logo_base64:
        return None
    try:
        raw = base64.b64decode(branding.logo_base64, validate=True)
        if len(raw) > 2_000_000:
            raise ValueError("Logo must be smaller than 2 MB.")
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(raw)) as image:
                if image.format not in ("PNG", "JPEG"):
                    raise ValueError("Only PNG and JPEG logos are supported.")
                if image.width * image.height > 4_000_000:
                    raise ValueError("Logo dimensions must not exceed 4 million pixels.")
                image.load()
                image = image.convert("RGBA")
                image.thumbnail((900, 300))
                output = BytesIO()
                image.save(output, format="PNG")
                return output.getvalue()
    except (
        binascii.Error,
        UnidentifiedImageError,
        OSError,
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
    ):
        raise ValueError("Invalid logo. Upload a valid PNG or JPEG smaller than 2 MB.") from None


def format_docx(text: str, doc_type: str, branding: Branding, logo: bytes | None = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin, section.bottom_margin = Inches(0.85), Inches(0.8)
    section.left_margin = section.right_margin = Inches(0.8)
    font = "Times New Roman" if branding.font == "serif" else "Arial"
    for name in ["Normal", "Title", "Heading 1", "Heading 2"]:
        style = doc.styles[name]
        style.font.name, style.font.color.rgb = font, RGBColor(0, 0, 0)
    normal = doc.styles["Normal"]
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.15
    doc.styles["Title"].font.size = Pt(23)
    doc.styles["Heading 1"].font.size = Pt(13)
    header = section.header.paragraphs[0]
    if logo:
        with Image.open(BytesIO(logo)) as image:
            width = min(1.5, 0.45 * image.width / image.height)
        header.add_run().add_picture(BytesIO(logo), width=Inches(width))
        header.add_run("  ")
    header.add_run(sanitize_text(branding.company_name)).bold = True
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("DRAFT FOR REVIEW  |  Page ").font.size = Pt(8)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    blocks = parse_document(text)
    if not blocks or blocks[0].kind != "title":
        doc.add_paragraph(sanitize_text(doc_type), "Title")
    table, index = None, 0
    for block in blocks:
        if block.kind == "term":
            if table is None:
                table = doc.add_table(rows=1, cols=2)
                table.style = "Table Grid"
                table.autofit = False
                table.columns[0].width, table.columns[1].width = Inches(0.5), Inches(6.4)
                table.cell(0, 0).text, table.cell(0, 1).text = "No.", "Term"
                repeat = OxmlElement("w:tblHeader")
                table.rows[0]._tr.get_or_add_trPr().append(repeat)
                for cell in table.rows[0].cells:
                    shade = OxmlElement("w:shd")
                    shade.set(qn("w:fill"), "E8EEF0")
                    cell._tc.get_or_add_tcPr().append(shade)
                    cell.paragraphs[0].runs[0].bold = True
                index = 0
            index += 1
            cells = table.add_row().cells
            cells[0].width, cells[1].width = Inches(0.5), Inches(6.4)
            cells[0].text, cells[1].text = str(index), block.text
        else:
            if table is not None:
                doc.add_paragraph()
            table = None
            style = {"title": "Title", "heading": "Heading 1", "bullet": "List Bullet", "paragraph": "Normal"}[
                block.kind
            ]
            doc.add_paragraph(block.text, style)
    doc.add_paragraph(NOTICE).runs[0].font.size = Pt(9)
    result = BytesIO()
    doc.save(result)
    return result.getvalue()


class LegalPDF(FPDF):
    def __init__(self, branding: Branding, logo: bytes | None):
        super().__init__(format="Letter")
        self.branding, self.logo = branding, logo
        base = "DejaVuSerif" if branding.font == "serif" else "DejaVuSans"
        for style, suffix in [("", ""), ("B", "-Bold")]:
            self.add_font("Legal", style, str(ROOT / "assets" / "fonts" / f"{base}{suffix}.ttf"))
        self.set_margins(20, 30, 20)
        self.set_auto_page_break(True, margin=21)

    def header(self):
        self.set_font("Legal", "B", 9)
        self.set_text_color(70, 78, 81)
        if self.logo:
            self.image(BytesIO(self.logo), x=20, y=10, w=24, h=12, keep_aspect_ratio=True)
        self.set_xy(48 if self.logo else 20, 12)
        self.cell(0, 6, self.branding.company_name, align="R")
        self.set_draw_color(205, 211, 215)
        self.line(20, 25, self.w - 20, 25)
        self.set_xy(20, 32)

    def footer(self):
        self.set_y(-14)
        self.set_font("Legal", "", 8)
        self.set_text_color(90, 90, 90)
        self.cell(0, 6, f"DRAFT FOR REVIEW  |  {self.page_no()}", align="C")


def format_pdf(text: str, doc_type: str, branding: Branding, logo: bytes | None = None) -> bytes:
    pdf = LegalPDF(branding, logo)
    pdf.set_title(sanitize_text(doc_type))
    pdf.set_author(sanitize_text(branding.company_name))
    # Never silently lose unsupported characters from a legal document.
    all_text = sanitize_text(text + branding.company_name + doc_type)
    regular = pdf.fonts["legal"]
    bold = pdf.fonts["legalB"]
    missing = {c for c in all_text if c not in "\n\t" and (ord(c) not in regular.cmap or ord(c) not in bold.cmap)}
    if missing:
        raise ValueError(
            "PDF font does not cover some characters. Use DOCX/TXT or replace those characters; supported interface languages use Latin scripts."
        )
    pdf.add_page()
    blocks = parse_document(text)
    if not blocks or blocks[0].kind != "title":
        pdf.set_font("Legal", "B", 20)
        pdf.multi_cell(0, 9, sanitize_text(doc_type), new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)
    i = 0
    while i < len(blocks):
        block = blocks[i]
        pdf.set_text_color(20, 27, 30)
        if block.kind == "term":
            terms = []
            while i < len(blocks) and blocks[i].kind == "term":
                terms.append(blocks[i].text)
                i += 1
            pdf.set_font("Legal", "", 10)
            with pdf.table(
                col_widths=(13, 163),
                line_height=5.5,
                padding=2.4,
                headings_style=FontFace(emphasis="B", fill_color=(232, 238, 240)),
                borders_layout="ALL",
                repeat_headings=1,
            ) as table:
                row = table.row()
                row.cell("No.")
                row.cell("Term")
                for n, term in enumerate(terms, 1):
                    # Split huge terms into continuation rows so no row exceeds one page.
                    for part, chunk in enumerate(
                        textwrap.wrap(term, 650, break_long_words=True, replace_whitespace=False) or [""]
                    ):
                        row = table.row()
                        row.cell(str(n) if part == 0 else "cont.")
                        row.cell(chunk)
            pdf.ln(4)
            continue
        if block.kind in ("title", "heading"):
            pdf.ln(3)
            if pdf.will_page_break(22):
                pdf.add_page()
            pdf.set_font("Legal", "B", 20 if block.kind == "title" else 12)
            pdf.multi_cell(0, 9 if block.kind == "title" else 7, block.text, new_x="LMARGIN", new_y="NEXT")
        else:
            pdf.set_font("Legal", "", 10.5)
            value = ("• " if block.kind == "bullet" else "") + block.text
            pdf.multi_cell(0, 5.8, value, new_x="LMARGIN", new_y="NEXT")
            pdf.ln(2)
        i += 1
    pdf.ln(4)
    pdf.set_font("Legal", "", 9)
    pdf.multi_cell(0, 5, NOTICE, new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())


def export_document(request: ExportRequest) -> tuple[bytes, str]:
    logo = logo_bytes(request.branding)
    text = sanitize_text(request.document)
    if request.format == "txt":
        return text.encode("utf-8"), MIME["txt"]
    formatter = format_pdf if request.format == "pdf" else format_docx
    return formatter(text, request.document_type, request.branding, logo), MIME[request.format]
