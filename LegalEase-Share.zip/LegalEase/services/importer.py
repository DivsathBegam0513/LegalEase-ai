"""Bounded text extraction. No OCR, macros, external links or scripts execute."""

import base64
import binascii
from io import BytesIO
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from docx import Document
from pypdf import PdfReader

from models import ImportRequest
from services.text import sanitize_text


def extract_document(request: ImportRequest) -> str:
    try:
        raw = base64.b64decode(request.content_base64, validate=True)
    except binascii.Error:
        raise ValueError("Invalid file encoding.") from None
    if len(raw) > 5_000_000:
        raise ValueError("Documents must be smaller than 5 MB.")
    suffix = Path(request.filename).suffix.lower()
    try:
        if suffix == ".txt":
            text = raw.decode("utf-8-sig")
        elif suffix == ".docx":
            with ZipFile(BytesIO(raw)) as archive:
                if sum(item.file_size for item in archive.infolist()) > 20_000_000:
                    raise ValueError("The expanded DOCX file is too large.")
                if len(archive.infolist()) > 1000:
                    raise ValueError("The DOCX file contains too many parts.")
            doc = Document(BytesIO(raw))
            paragraphs = []
            for item in doc.iter_inner_content():
                if hasattr(item, "rows"):
                    paragraphs.extend(" | ".join(c.text for c in row.cells) for row in item.rows)
                else:
                    paragraphs.append(item.text)
            text = "\n".join(paragraphs)
        elif suffix == ".pdf":
            reader = PdfReader(BytesIO(raw))
            if reader.is_encrypted:
                raise ValueError("Password-protected PDFs are not supported.")
            if len(reader.pages) > 50:
                raise ValueError("PDFs must contain at most 50 pages.")
            chunks = []
            for page in reader.pages:
                content = page.get_contents()
                if content and len(content.get_data()) > 5_000_000:
                    raise ValueError("This PDF page is too complex to extract locally.")
                chunks.append(page.extract_text() or "")
                if sum(len(chunk) for chunk in chunks) > 60000:
                    raise ValueError("Extracted text exceeds 60,000 characters.")
            text = "\n".join(chunks)
        else:
            raise ValueError("Upload a TXT, DOCX or text-based PDF file.")
    except (UnicodeDecodeError, BadZipFile, KeyError):
        raise ValueError("Unable to read this file. Check its format; TXT files must use UTF-8.") from None
    except ValueError:
        raise
    except Exception:
        raise ValueError(
            "Unable to extract text from this document. Try a valid DOCX, UTF-8 TXT or text-based PDF."
        ) from None
    text = sanitize_text(text).strip()
    if len(text) < 30:
        raise ValueError("Not enough text found. Scanned PDFs need OCR before importing.")
    if len(text) > 60000:
        raise ValueError("Extracted text exceeds 60,000 characters.")
    return text
