"""A tiny, escaped document format shared by preview and file exports."""

from dataclasses import dataclass
from html import escape
import re
import unicodedata


@dataclass(frozen=True)
class Block:
    kind: str
    text: str


def sanitize_text(text: str) -> str:
    # Preserve Unicode punctuation and accents. Remove controls invalid in Word XML.
    text = unicodedata.normalize("NFC", text.replace("\r\n", "\n").replace("\r", "\n"))
    return "".join(c for c in text if c in "\n\t" or unicodedata.category(c) not in ("Cc", "Cs"))


def parse_document(text: str) -> list[Block]:
    blocks, in_terms = [], False
    for line in sanitize_text(text).splitlines():
        line = line.strip()
        if not line:
            continue
        if re.match(r"^#{1,6}\s", line):
            heading = line.lstrip("#").strip()
            in_terms = heading.casefold() == "key terms"
            blocks.append(Block("title" if line.startswith("# ") else "heading", heading))
        elif line.startswith(("- ", "* ")):
            blocks.append(Block("term" if in_terms else "bullet", line[2:].strip()))
        else:
            blocks.append(Block("term" if in_terms else "paragraph", line))
    return blocks


def format_html_preview(text: str) -> str:
    parts, terms, index = [], False, 0
    for block in parse_document(text):
        if block.kind != "term" and terms:
            parts.append("</tbody></table>")
            terms = False
        value = escape(block.text, quote=True)
        if block.kind == "term":
            if not terms:
                parts.append("<table><thead><tr><th>No.</th><th>Term</th></tr></thead><tbody>")
                terms, index = True, 0
            index += 1
            parts.append(f"<tr><td>{index:02d}</td><td>{value}</td></tr>")
        else:
            tag = {"title": "h2", "heading": "h3", "bullet": "p", "paragraph": "p"}[block.kind]
            parts.append(f"<{tag}>{'&#8226; ' if block.kind == 'bullet' else ''}{value}</{tag}>")
    if terms:
        parts.append("</tbody></table>")
    return '<article class="document-sheet">' + "".join(parts) + "</article>"
