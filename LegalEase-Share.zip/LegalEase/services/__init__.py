"""Pure in-memory document transformations."""
