import pytest
from fastapi.testclient import TestClient

from config import get_settings
from main import app
from security import _hits


@pytest.fixture(autouse=True)
def isolate_settings(monkeypatch):
    monkeypatch.setenv("AI_PROVIDER", "demo")
    monkeypatch.setenv("GEMINI_API_KEY", "")
    monkeypatch.setenv("BACKEND_API_KEY", "")
    monkeypatch.setenv("RATE_LIMIT_PER_MINUTE", "1000")
    get_settings.cache_clear()
    _hits.clear()
    yield
    get_settings.cache_clear()
    _hits.clear()


@pytest.fixture
def client():
    with TestClient(app) as value:
        yield value


@pytest.fixture
def payload():
    return {
        "document_type": "Non-Disclosure Agreement",
        "parties": "Northstar (Discloser); Riverbend (Recipient)",
        "terms": "Use only for project evaluation; Return materials on request",
        "dates": "2026-10-01",
        "jurisdiction": "To be confirmed",
        "language": "English",
    }
