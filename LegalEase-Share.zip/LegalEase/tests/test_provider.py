from types import SimpleNamespace

from google.genai import errors
import httpx
import pytest

from ai_core.gemini_generator import GeminiDocumentGenerator, GenerationError
from config import Settings
from models import AnalysisRequest, DocumentRequest


def fake_client(monkeypatch, *, text="", reason="STOP", error=None):
    captured = {}

    class Client:
        def __init__(self, **kwargs):
            captured["client"] = kwargs
            self.models = self

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def generate_content(self, **kwargs):
            captured["request"] = kwargs
            if error:
                raise error
            return SimpleNamespace(text=text, candidates=[SimpleNamespace(finish_reason=reason)])

    monkeypatch.setattr("ai_core.gemini_generator.genai.Client", Client)
    return captured


def generator():
    return GeminiDocumentGenerator(Settings(ai_provider="gemini", gemini_api_key="unit-test-key", _env_file=None))


def test_sdk_call_preserves_data_as_json(monkeypatch, payload):
    captured = fake_client(monkeypatch, text="# Draft\nThis is a complete test draft.")
    result = generator().generate_document(DocumentRequest(**payload))
    assert result.startswith("# Draft")
    call = captured["request"]
    assert call["model"] == "gemini-3.5-flash"
    assert "Northstar" in call["contents"]
    assert "untrusted" in call["config"].system_instruction
    options = captured["client"]["http_options"]
    assert options.timeout * options.retry_options.attempts + 1000 <= 90000
    assert call["config"].automatic_function_calling.disable is True


@pytest.mark.parametrize("text,reason", [("", "STOP"), ("partial document", "MAX_TOKENS"), ("blocked", "SAFETY")])
def test_bad_completion(monkeypatch, payload, text, reason):
    fake_client(monkeypatch, text=text, reason=reason)
    with pytest.raises(GenerationError):
        generator().generate_document(DocumentRequest(**payload))


@pytest.mark.parametrize(
    "code,status", [(429, 429), (402, 502), (403, 502), (404, 502), (500, 502), (503, 503), (504, 504)]
)
def test_provider_errors_do_not_expose_secrets(monkeypatch, payload, code, status):
    fake_client(
        monkeypatch, error=errors.APIError(code, {"error": {"message": "private-secret-content", "code": code}})
    )
    with pytest.raises(GenerationError) as exc:
        generator().generate_document(DocumentRequest(**payload))
    assert exc.value.status_code == status
    assert "private-secret" not in str(exc.value)


def test_timeout(monkeypatch, payload):
    fake_client(monkeypatch, error=httpx.ReadTimeout("secret content"))
    with pytest.raises(GenerationError) as exc:
        generator().generate_document(DocumentRequest(**payload))
    assert exc.value.status_code == 504


def test_analysis_schema(monkeypatch):
    fake_client(
        monkeypatch,
        text='{"summary":"A sample agreement.","key_clauses":["Payment"],"review_points":["Confirm the due date."]}',
    )
    assert generator().analyze(AnalysisRequest(document="Example agreement with a payment clause.")).key_clauses == [
        "Payment"
    ]
    fake_client(monkeypatch, text="not json")
    with pytest.raises(GenerationError):
        generator().analyze(AnalysisRequest(document="Example agreement with a payment clause."))


@pytest.mark.parametrize(
    "code,eventual_success,expected_calls", [(503, True, 2), (503, False, 2), (429, False, 1), (403, False, 1)]
)
def test_real_sdk_retry_policy(monkeypatch, payload, code, eventual_success, expected_calls):
    """Exercise SDK retries with an in-memory HTTP transport; never call Google."""
    from google import genai

    real_client = genai.Client
    calls = []

    def handle(request):
        calls.append(request)
        if eventual_success and len(calls) == 2:
            return httpx.Response(
                200,
                json={
                    "candidates": [
                        {
                            "content": {
                                "role": "model",
                                "parts": [{"text": "# Test draft\nA completed fictional draft."}],
                            },
                            "finishReason": "STOP",
                        }
                    ]
                },
            )
        return httpx.Response(
            code, json={"error": {"code": code, "status": "UNAVAILABLE", "message": "private-provider-detail"}}
        )

    def client_with_transport(**kwargs):
        kwargs["http_options"].client_args = {"transport": httpx.MockTransport(handle)}
        return real_client(**kwargs)

    monkeypatch.setattr("ai_core.gemini_generator.genai.Client", client_with_transport)
    if eventual_success:
        assert "completed fictional draft" in generator().generate_document(DocumentRequest(**payload))
    else:
        with pytest.raises(GenerationError) as exc:
            generator().generate_document(DocumentRequest(**payload))
        assert "private-provider-detail" not in str(exc.value)
        if code == 503:
            assert exc.value.status_code == 503
            assert "overloaded" in str(exc.value)
    assert len(calls) == expected_calls
