import base64
from io import BytesIO

from docx import Document
from PIL import Image
from pypdf import PdfReader
import pytest

from config import get_settings


def test_health_and_generation(client, payload):
    assert client.get("/").status_code == 200
    assert client.get("/health").json()["provider"] == "demo"
    result = client.post("/generate", json=payload)
    assert result.status_code == 200
    body = result.json()
    assert body["provider"] == "demo"
    assert "NOT AI-GENERATED" in body["document"]
    assert payload["parties"] in body["document"]
    assert "## Key Terms" in body["document"]
    assert result.headers["cache-control"] == "no-store"


@pytest.mark.parametrize(
    "kind,section",
    [
        ("Employment Contract", "Role and compensation"),
        ("Residential Lease Agreement", "Premises and occupancy"),
        ("Freelance Work Contract", "Services and deliverables"),
        ("Custom Partnership Agreement", "Purpose and scope"),
    ],
)
def test_document_scenarios(client, payload, kind, section):
    response = client.post("/generate", json={**payload, "document_type": kind})
    assert response.status_code == 200
    text = response.json()["document"]
    assert text.startswith("# " + kind)
    assert section in text
    assert payload["dates"] in text
    assert payload["terms"].split(";")[0] in text


@pytest.mark.parametrize(
    "field,value",
    [("parties", " "), ("terms", "x"), ("document_type", "ab"), ("language", "Klingon"), ("terms", "x;" * 61)],
)
def test_validation(client, payload, field, value):
    result = client.post("/generate", json={**payload, field: value})
    assert result.status_code == 422
    assert all("input" not in error for error in result.json()["detail"])


def test_demo_language_and_missing_key(client, payload, monkeypatch):
    assert client.post("/generate", json={**payload, "language": "French"}).status_code == 422
    monkeypatch.setenv("AI_PROVIDER", "gemini")
    get_settings.cache_clear()
    assert not client.get("/health").json()["configured"]
    result = client.post("/generate", json=payload)
    assert result.status_code == 503
    assert "GEMINI_API_KEY" in result.json()["detail"]


def test_auth_and_rate_limit(client, payload, monkeypatch):
    monkeypatch.setenv("BACKEND_API_KEY", "test-token")
    monkeypatch.setenv("RATE_LIMIT_PER_MINUTE", "1")
    get_settings.cache_clear()
    assert client.post("/generate", json=payload).status_code == 401
    assert client.post("/generate", json=payload, headers={"X-API-Key": "wrong"}).status_code == 401
    assert client.post("/generate", json=payload, headers={"X-API-Key": "test-token"}).status_code == 200
    assert client.post("/generate", json=payload, headers={"X-API-Key": "test-token"}).status_code == 429


def test_oversized_body(client):
    assert client.post("/generate", content=b"x" * 8_000_001).status_code == 413


@pytest.mark.parametrize("extension", ["txt", "docx", "pdf"])
def test_current_edits_roundtrip(client, payload, extension):
    text = client.post("/generate", json=payload).json()["document"]
    text = text.replace("Return materials on request", "REVISED TERM: return materials in 7 days")
    result = client.post(
        "/export",
        json={
            "document": text,
            "format": extension,
            "document_type": "../NDA\r\n",
            "branding": {"company_name": "Test Brand"},
        },
    )
    assert result.status_code == 200, result.text
    assert 'filename="NDA.' in result.headers["content-disposition"]
    if extension == "txt":
        extracted = result.content.decode("utf-8")
    elif extension == "docx":
        doc = Document(BytesIO(result.content))
        assert doc.sections[0].header.paragraphs[0].text == "Test Brand"
        extracted = "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    else:
        reader = PdfReader(BytesIO(result.content))
        extracted = "\n".join(p.extract_text() for p in reader.pages)
        assert "Test Brand" in extracted
    assert "REVISED TERM" in extracted
    assert "Return materials on request" not in extracted


def test_unicode_branded_pdf_and_docx(client):
    buf = BytesIO()
    Image.new("RGB", (100, 40), "#204e50").save(buf, "PNG")
    branding = {
        "company_name": "Élan & Société",
        "logo_base64": base64.b64encode(buf.getvalue()).decode(),
        "font": "sans",
    }
    text = "# Contrat de services\n\n## Key Terms\n- Café, coût: 500 € — gültig.\n- Pago después de la entrega."
    for fmt in ["pdf", "docx"]:
        result = client.post("/export", json={"document": text, "format": fmt, "branding": branding})
        assert result.status_code == 200, result.text
        if fmt == "pdf":
            pages = PdfReader(BytesIO(result.content)).pages
            assert "500 €" in "\n".join(p.extract_text() for p in pages)
            assert any(len(p.images) for p in pages)
        else:
            from zipfile import ZipFile

            assert any(n.startswith("word/media/") for n in ZipFile(BytesIO(result.content)).namelist())


def test_invalid_logo_and_unsupported_pdf_glyph(client):
    req = {"document": "This is a sample document for review.", "format": "pdf"}
    assert client.post("/export", json={**req, "branding": {"logo_base64": "not-base64"}}).status_code == 422
    assert client.post("/export", json={**req, "document": req["document"] + " 中文"}).status_code == 422


def test_long_terms_paginate(client):
    text = "# Long agreement\n## Key Terms\n" + "\n".join("- " + ("Long reviewable term " * 90) for _ in range(10))
    result = client.post("/export", json={"document": text, "format": "pdf"})
    assert result.status_code == 200, result.text
    pages = PdfReader(BytesIO(result.content)).pages
    assert len(pages) > 2
    assert all("DRAFT FOR REVIEW" in p.extract_text() for p in pages)


def test_review_and_import(client):
    text = "# Agreement\n## Payment\nPay within 30 days.\n[TO BE COMPLETED: name]"
    result = client.post("/analyze", json={"document": text})
    assert result.status_code == 200
    assert "Payment" in result.json()["key_clauses"]
    assert len(result.json()["review_points"]) == 2
    imported = client.post(
        "/extract", json={"filename": "example.txt", "content_base64": base64.b64encode(text.encode()).decode()}
    )
    assert imported.json()["document"] == text
    for fmt in ["pdf", "docx"]:
        data = client.post("/export", json={"document": text, "format": fmt}).content
        response = client.post(
            "/extract", json={"filename": "file." + fmt, "content_base64": base64.b64encode(data).decode()}
        )
        assert response.status_code == 200
        assert "Pay within 30 days" in response.json()["document"]


@pytest.mark.parametrize(
    "name,data",
    [
        ("bad.exe", b"MZ fake"),
        ("bad.docx", b"bad zip"),
        ("bad.pdf", b"bad PDF"),
        ("bad.txt", b"\xff\xfe"),
        ("short.txt", b"tiny"),
    ],
)
def test_bad_import(client, name, data):
    assert (
        client.post("/extract", json={"filename": name, "content_base64": base64.b64encode(data).decode()}).status_code
        == 422
    )
