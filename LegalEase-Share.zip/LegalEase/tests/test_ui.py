from streamlit.testing.v1 import AppTest

from config import ROOT
from frontend.api_client import APIError
from services.text import format_html_preview


def test_preview_escapes_html():
    value = format_html_preview("# <script>alert(1)</script>\n## Key Terms\n- <img src=x onerror=alert(1)>")
    assert "<script>" not in value
    assert "<img" not in value
    assert "&lt;script&gt;" in value
    assert "<table>" in value


def test_ui_generate_edit_review_export_clear(client, monkeypatch):
    def adapter(path, payload=None, *, binary=False):
        result = client.get(path) if payload is None else client.post(path, json=payload)
        if result.is_error:
            raise APIError(str(result.json()["detail"]))
        return result.content if binary else result.json()

    monkeypatch.setattr("frontend.app.request_api", adapter)
    at = AppTest.from_file(ROOT / "app.py", default_timeout=30).run()
    assert not at.exception
    at.text_area(key="parties").input("Alice (Client); Bob (Provider)")
    at.text_area(key="terms").input("Deliver the work on time; Fee: EUR 500")
    next(b for b in at.button if b.label == "Generate draft").click().run()
    assert not at.exception
    assert "Alice" in at.session_state["document"]
    at.text_area(key="editor").input(at.session_state["document"].replace("EUR 500", "EUR 900"))
    next(b for b in at.button if b.label == "Apply edits").click().run()
    assert "EUR 900" in at.session_state["document"]
    next(b for b in at.button if b.label == "Review saved draft").click().run()
    assert at.session_state["analysis"]["provider"] == "demo"
    next(b for b in at.button if b.label == "Prepare downloads").click().run()
    assert not at.exception
    assert set(at.session_state["downloads"]) == {"txt", "docx", "pdf"}
    assert b"EUR 900" in at.session_state["downloads"]["txt"]
    at.text_area(key="editor").input(at.session_state["document"].replace("EUR 900", "EUR 950"))
    next(b for b in at.button if b.label == "Apply edits").click().run()
    assert "downloads" not in at.session_state
    assert "analysis" not in at.session_state
    next(b for b in at.button if b.label == "Clear workspace").click().run()
    assert not at.exception
    assert "document" not in at.session_state


def test_ui_offline_and_invalid_input(client, monkeypatch):
    def down(*args, **kwargs):
        raise APIError("Offline")

    monkeypatch.setattr("frontend.app.request_api", down)
    at = AppTest.from_file(ROOT / "app.py").run()
    assert not at.exception
    assert next(b for b in at.button if b.label == "Generate draft").disabled
