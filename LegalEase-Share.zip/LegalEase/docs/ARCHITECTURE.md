# Architecture

The frontend and backend are independent Python processes. `run.py` starts both on loopback, waits for health, reports startup failures and shuts down its children on Ctrl+C.

```mermaid
flowchart LR
    User[Browser] --> UI[Streamlit app]
    UI -->|JSON over HTTP| API[FastAPI routes]
    API --> Validate[Pydantic validation]
    Validate --> Provider{Configured provider}
    Provider --> Demo[Offline templates]
    Provider --> Gemini[Google Gen AI SDK]
    API --> Export[TXT DOCX PDF exporters]
    API --> Import[Bounded text extraction]
    Gemini --> Google[Google Gemini API]
```

## Request lifecycle

An ASGI middleware caps JSON bodies at 8 MB, including chunked bodies. POST routes require the optional X-API-Key and use a lock-protected, per-client-IP, process-local rate limit. Pydantic bounds field lengths. Blocking provider calls, parsing and rendering run in FastAPI worker threads.

Provider instructions are separate from user data serialized as JSON. There are no model tools, code execution or URL fetches. Output is treated as untrusted text, escaped for HTML and parsed through a small heading/bullet format. A provider timeout, blocked/truncated result, quota failure or invalid analysis schema is returned as a bounded error rather than a successful document. The SDK makes at most two attempts for HTTP 500/502/503/504 failures, with a one-second delay. Attempts share the configured timeout budget. Authentication, billing and quota failures are not automatically retried. Automatic function calling is disabled because this app does not use model tools.

## Single source of truth for edits

The browser holds a Streamlit session. A generated/imported draft becomes `session_state.document`. The editor form commits only on Apply edits. Preview, analysis and export all read that saved text. Mutating it invalidates prepared downloads and review notes. Export form submission creates a byte snapshot for download; download buttons do not initiate a rerun. Drafts are not shared through a cache or database.

The `## Key Terms` heading starts a term region; bullets or plain lines until the next Markdown heading become table rows. TXT retains the text representation. Word and PDF render real tables. Do not rename the heading if you want automatic tables. Other Markdown features are displayed as plain text, not executed.

## Formatting and files

PDF uses fpdf2 with bundled DejaVu fonts and validates glyph coverage before writing. DOCX uses python-docx, installed Word fonts, page numbering and a repeating table header. Logos are base64-decoded, checked for format, byte size and pixel count, resized and re-encoded as PNG with metadata discarded. All exports use BytesIO or bytes, not shared temporary filenames.

Imports support UTF-8 TXT, DOCX with bounded ZIP expansion, and text-based PDF with page/content limits. No original layout fidelity, OCR, macro execution or hyperlink fetching is provided. Parser resource limits reduce accidental overload; these are not a sandbox for adversarial public uploads.

## Operational boundaries

`/health` reports configuration presence, not remote provider availability. The local limiter is not distributed; use an external/shared limiter for multiple workers. The app has no durable storage, identity provider or secret manager. Backend logs include route/status information, not legal document bodies. Public deployment requires additional infrastructure described in README.md. Containers are optional and were not runtime-tested here.
